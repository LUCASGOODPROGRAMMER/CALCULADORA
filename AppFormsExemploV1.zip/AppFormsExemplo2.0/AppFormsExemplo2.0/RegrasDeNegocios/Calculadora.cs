﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppFormsExemplo3.RegrasDeNegocios
{
    public class Calculadora
    {
        //atributos
        public double Valor1 { get; set; }
        public double Valor2 { get; set; }
        public double Valor3 { get; set; }
            public double Resultado { get; set; }

        //Métodos

        public void CalcularSoma()
        {
            Resultado = Valor1 + Valor2;
        }
        public void CalcularMultiplicacao()
        {
            Resultado = Valor1 * Valor2;
        }
        public void CalcularDivisao()
        {
            Resultado = Valor1 / Valor2;
        }
        public void CalvularVolumeCubico()
        {
            Resultado = Valor1 * Valor2 * Valor3;
            //Valor1 = comprimento; Valor2 = largura; Valor3 = altura;
        }
        public void CalcularAreaRetangular()
        {
            Resultado = Valor1 * Valor2;
            //Valor1 = base; Valor2 = altura
        }
        public void CalcularPotencia()
        {
            Resultado = Math.Pow(Valor1, Valor2);
            //Valor1 = base; Valor2 = expoente;
        }
    }
}
