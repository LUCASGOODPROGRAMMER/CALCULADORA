﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppFormsExemplo3.RegrasDeNegocios;
namespace AppFormsExemplo3.Formulario
{
    public partial class FormSoma : Form
    {
        public FormSoma()
        {
            InitializeComponent();
        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
             Calculadora calc = new Calculadora();
            calc.Valor1 = Convert.ToInt32(txtValor1.Text);
            calc.Valor2 = Convert.ToInt32(txtValor2.Text);
            calc.CalcularSoma();//processamento
            txtResultado.Text = calc.Resultado.ToString();
        }
    }
}
