﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppFormsExemplo2._0.Formulario
{
    public partial class FormMultiplicacao : Form
    {
        public FormMultiplicacao()
        {
            InitializeComponent();
        }
    }
}
